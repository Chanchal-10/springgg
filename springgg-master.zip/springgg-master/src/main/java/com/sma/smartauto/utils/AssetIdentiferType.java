package com.sma.smartauto.utils;

public enum AssetIdentiferType {
	A, B, C
}
